#pragma once
#include "CSubsetBaseVisitor.h"
#include "2205134_symbol_table.h"
// #include "2205134_AuxInfo.h"

using namespace std;

int errCount = 0;

extern ofstream logFile;
extern ofstream errorFile;


void logRule(antlr4::ParserRuleContext *ctx, string rule)
{
  logFile << "Line " << ctx->getStart()->getLine() << ": " << rule << "\n\n";
  // logFile<<ctx->getText()<<"\n\n";
  // thanks to claude
  std::string matchedText = ctx->getStart()->getInputStream()->getText(
      antlr4::misc::Interval(ctx->getStart()->getStartIndex(), ctx->getStop()->getStopIndex()));
  logFile << matchedText << "\n\n";
}

void logRule(antlr4::ParserRuleContext *ctx, string rule, string matchedText)
{
  logFile << "Line " << ctx->getStart()->getLine() << ": " << rule << "\n\n";
  // logFile<<ctx->getText()<<"\n\n";
  logFile << matchedText << "\n\n";
}

void logError(antlr4::ParserRuleContext *ctx, string error)
{
  errCount++;
  errorFile << "Error at line " << ctx->getStart()->getLine() << ": " << error << "\n\n";
  logFile << "Error at line " << ctx->getStart()->getLine() << ": " << error << "\n\n";
}

class ParamInfo{
  public:
    DataType dataType;
    bool hasId;
    ParamInfo(DataType dt, bool hasId){
      this->dataType = dt;
      this->hasId = hasId;
    }
};

// string intFloatCheck(string t1, string t2)
// {
//   if ((t1 == string("int") && t2 == string("int")) || (t1 == string("float") && t2 == string("float")))
//   {
//     // no casting needed
//     return t1;
//   }
//   else if ((t1 == string("int") && t2 == string("float")) || (t1 == string("float") && t2 == string("int")))
//   {
//     // operand cast to float from int
//     return string("float");
//   }
//   return string("");
// }

DataType intFloatCheck(DataType t1, DataType t2)
{
  if (t1 == DataType::ERROR || t2 == DataType::ERROR)
  {
    return DataType::ERROR;
  }
  if (t1 == t2)
  {
    if (t1 == DataType::INT || t1 == DataType::FLOAT)
    {
      return t1;
    }
  }
  else
  {
    if ((t1 == DataType::INT && t2 == DataType::FLOAT) || (t1 == DataType::FLOAT && t2 == DataType::INT))
    {
      return DataType::FLOAT;
    }
  }
  return DataType::ERROR;
}

DataType intFloatAssignCheck(DataType t1, DataType t2)
{
  if (t1 == DataType::ERROR || t2 == DataType::ERROR)
  {
    return DataType::ERROR;
  }
  if (t1 == t2)
  {
    if (t1 == DataType::INT || t1 == DataType::FLOAT)
    {
      // no casting needed
      return t1;
    }
  }
  else if (t1 == DataType::FLOAT && t2 == DataType::INT)
  {
    // operand cast to float from int
    return DataType::FLOAT;
  }
  // according to error2.txt, this is not allowed
  //  else if (t1 == DataType::INT && t2 == DataType::FLOAT)
  //  {
  //    return DataType::INT;
  //  }
  return DataType::ERROR;
}

// string intFloatAssignCheck(string t1, string t2){
//   if ((t1 == string("int") && t2 == string("int")) || (t1 == string("float") && t2 == string("float")))
//   {
//     // no casting needed
//     return t1;
//   }
//   else if (t1 == string("float") && t2 == string("int"))
//   {
//     // operand cast to float from int
//     return string("float");
//   }
//   else if(t1 == string("int") && t2 == string("float")){
//     return string("int");
//   }
//   return string("");
// }

class CSubset : public CSubsetBaseVisitor
{

private:
  SymbolTable *symbolTable;

public:
  CSubset()
  {
    this->symbolTable = new SymbolTable(30);
  }
  any visitStart(CSubsetParser::StartContext *ctx) override
  {
    visit(ctx->program());
    // logRule(ctx, "start : program");
    logFile << "Line " << ctx->getStart()->getLine() << ": start : program\n\n";
    symbolTable->printAllScopeTableNonEmpty();
    logFile << "\n";
    logFile << "Total lines: " << ctx->getStop()->getLine() << "\n";
    logFile << "Total errors: " << errCount << "\n";
    return nullptr;
  }

  any visitProgramUnit(CSubsetParser::ProgramUnitContext *ctx) override
  {
    visit(ctx->unit());
    logRule(ctx, "program : unit");
    return nullptr;
  }

  any visitProgramAgain(CSubsetParser::ProgramAgainContext *ctx) override
  {
    visit(ctx->program());
    visit(ctx->unit());
    logRule(ctx, "program : program unit");
    return nullptr; //?
  }

  any visitUnitVarDeclaration(CSubsetParser::UnitVarDeclarationContext *ctx) override
  {
    visit(ctx->var_declaration());
    logRule(ctx, "unit : var_declaration");
    return nullptr;
  }

  any visitUnitFuncDeclaration(CSubsetParser::UnitFuncDeclarationContext *ctx) override
  {
    visit(ctx->func_declaration());
    logRule(ctx, "unit : func_declaration");
    return nullptr;
  }

  any visitUnitFuncDefinition(CSubsetParser::UnitFuncDefinitionContext *ctx) override
  {
    visit(ctx->func_definition());
    logRule(ctx, "unit : func_definition");
    return nullptr;
  }

  any visitFuncDeclarationWParameters(CSubsetParser::FuncDeclarationWParametersContext *ctx) override
  {
    visit(ctx->type_specifier());
    string retType = ctx->type_specifier()->getText();
    SymbolInfo *symbol = new SymbolInfo(ctx->ID()->getText(), "ID", retType);
    if (!symbolTable->insert(symbol))
    {
      logError(ctx, "Function already declared");
      return nullptr;
    }
    symbolTable->enterScope();
    vector<ParamInfo> parameters = any_cast<vector<ParamInfo>>(visit(ctx->parameter_list()));
    AuxInfo *funcInfo = symbol->getAuxInfo();
    vector<DataType> dataTypes;
    for(int i = 0; i < parameters.size(); i++){
      dataTypes.push_back(parameters[i].dataType);
    }
    funcInfo->setArgTypes(dataTypes);
    symbolTable->exitScope(false); // for function declaration, don't print scope tables
    logRule(ctx, "func_declaration : type_specifier ID LPAREN parameter_list RPAREN SEMICOLON");
    return nullptr;
  }

  any visitFuncDeclarationWoParameters(CSubsetParser::FuncDeclarationWoParametersContext *ctx) override
  {
    visit(ctx->type_specifier());
    string retType = ctx->type_specifier()->getText();
    SymbolInfo *symbol = new SymbolInfo(ctx->ID()->getText(), "ID", retType);
    if (!symbolTable->insert(symbol))
    {
      logError(ctx, "Function already declared");
      return nullptr;
    }
    symbolTable->enterScope();
    vector<DataType> parameters;
    AuxInfo *funcInfo = symbol->getAuxInfo();
    funcInfo->setArgTypes(parameters);
    symbolTable->exitScope(false);
    logRule(ctx, "func_declaration : type_specifier ID LPAREN RPAREN SEMICOLON");
    return nullptr;
  }

  any visitFuncDefWParameters(CSubsetParser::FuncDefWParametersContext *ctx) override
  {
    visit(ctx->type_specifier());
    string retType = ctx->type_specifier()->getText();
    string funcName = ctx->ID()->getText();
    SymbolInfo *symbol = new SymbolInfo(funcName, "ID", retType);
    bool declared = false;
    SymbolInfo *found = symbolTable->lookUp(funcName);
    if (found != NULL && found->getAuxInfo()->getArgCount() == -1)
    {
      // declared before, but not function
      string err = "Multiple declaration of " + funcName;
      logError(ctx, err);
    }
    else if (found != NULL)
    {
      // is declared beforehand
      declared = true;
      if (found->getAuxInfo()->getDataType() != stringToType(retType))
      {
        string err = "Return type mismatch with function declaration in function " + funcName;
        logError(ctx, err);
        // return nullptr;
      }
    }
    else
    {
      symbolTable->insert(symbol);
    }
    symbolTable->enterScope();
    vector<ParamInfo> parameters = any_cast<vector<ParamInfo>>(visit(ctx->parameter_list()));
    AuxInfo *funcInfo = symbol->getAuxInfo();
    vector<DataType> argTypes;
    for(int i = 0; i < parameters.size(); i++){
      argTypes.push_back(parameters[i].dataType);
      if(!parameters[i].hasId){
        string err = to_string(i+1) + "th parameter's name not given in function definition of "+funcName;
        logError(ctx, err);
      }
    }
    funcInfo->setArgTypes(argTypes);
    
    if (declared)
    {
      vector<DataType> declaredTypes = found->getAuxInfo()->getArgTypes();
      
      if (parameters.size() != declaredTypes.size())
      {
        string err = "Total number of arguments mismatch with declaration in function " + funcName;
        logError(ctx, err);
      }
      else
      {
        for (int i = 0; i < declaredTypes.size(); i++)
        {
          if (parameters[i].dataType != declaredTypes[i])
          {
            string err = "Parameter " + to_string(i + 1) + " does not match with declaration ";
            logError(ctx, err);
            // return nullptr; //
          }
        }
      }
    }
    visit(ctx->compound_statement());
    symbolTable->exitScope();
    logRule(ctx, "func_definition : type_specifier ID LPAREN parameter_list RPAREN compound_statement");
    return nullptr;
  }

  any visitFuncDefWoParameters(CSubsetParser::FuncDefWoParametersContext *ctx) override
  {
    visit(ctx->type_specifier());
    string retType = ctx->type_specifier()->getText();
    string funcName = ctx->ID()->getText();
    SymbolInfo *symbol = new SymbolInfo(funcName, "ID", retType);
    SymbolInfo *found = symbolTable->lookUp(funcName);

    bool declared = false;
    if (found != NULL && found->getAuxInfo()->getArgCount() == -1)
    {
      // declared before, but not function
      string err = "Multiple declaration of " + funcName;
      logError(ctx, err);
    }
    else if (found != NULL)
    {
      // is declared beforehand
      declared = true;
      if (found->getAuxInfo()->getDataType() != stringToType(retType))
      {
        string err = "Return type mismatch with function declaration in function " + funcName;
        logError(ctx, err);
        // return nullptr;
      }
    }
    else
    {
      symbolTable->insert(symbol);
    }
    symbolTable->enterScope();
    vector<DataType> parameters;
    AuxInfo *funcInfo = symbol->getAuxInfo();
    funcInfo->setArgTypes(parameters);
    if (declared)
    {
      vector<DataType> declaredTypes = found->getAuxInfo()->getArgTypes();
      if (!declaredTypes.empty())
      {
        string err = "Previous declaration of " + funcName + " has parameters ";
        logError(ctx, err);
        // return nullptr;
      }
    }
    visit(ctx->compound_statement());
    symbolTable->exitScope();
    logRule(ctx, "func_definition : type_specifier ID LPAREN RPAREN compound_statement");
    return nullptr;
  }

  any visitStrayTokenParameterList(CSubsetParser::StrayTokenParameterListContext *ctx) override {
    visit(ctx->type_specifier());
    string type = ctx->type_specifier()->getText();
    vector<ParamInfo> types;
    types.push_back(ParamInfo(stringToType(type), false));
    logRule(ctx->type_specifier(), "parameter_list : type_specifier"); //sample output shows int only instead of int-, sending ctx->type_specifier(), now getText() will be called on that
    string err = "syntax error, unexpected token(s) '"+ctx->getStop()->getText()+"' before ')'";
    logError(ctx, err);
    return types;
    //parameter_list : type_specifier .
  }

  any visitSingleParameterWoId(CSubsetParser::SingleParameterWoIdContext *ctx) override
  {
    visit(ctx->type_specifier());
    string type = ctx->type_specifier()->getText();
    vector<ParamInfo> types;
    types.push_back(ParamInfo(stringToType(type), false));
    logRule(ctx, "parameter_list : type_specifier");
    return types;
  }

  any visitSingleParameterWId(CSubsetParser::SingleParameterWIdContext *ctx) override
  {
    visit(ctx->type_specifier());
    visit(ctx->ID());
    string type = ctx->type_specifier()->getText();
    string name = ctx->ID()->getText();
    SymbolInfo *symbol = new SymbolInfo(name, "ID", type);
    vector<ParamInfo> types;
    if (!symbolTable->insert(symbol))
    {
      string err = "Multiple declaration of " + name + " in parameter";
      logError(ctx, err);
      //return types;
    }
    types.push_back(ParamInfo(stringToType(type), true));
    logRule(ctx, "parameter_list : type_specifier ID");
    return types;
  }

  any visitMultipleParametersWoId(CSubsetParser::MultipleParametersWoIdContext *ctx) override
  {
    vector<ParamInfo> types = any_cast<vector<ParamInfo>>(visit(ctx->parameter_list()));
    visit(ctx->type_specifier());
    string type = ctx->type_specifier()->getText();
    types.push_back(ParamInfo(stringToType(type), false));
    logRule(ctx, "parameter_list : parameter_list COMMA type_specifier");
    return types;
  }

  any visitMultipleParametersWId(CSubsetParser::MultipleParametersWIdContext *ctx) override
  {
    vector<ParamInfo> types = any_cast<vector<ParamInfo>>(visit(ctx->parameter_list()));
    visit(ctx->type_specifier());
    string type = ctx->type_specifier()->getText();
    types.push_back(ParamInfo(stringToType(type), true));

    string name = ctx->ID()->getText();
    SymbolInfo *symbol = new SymbolInfo(name, "ID", type);
    if (!symbolTable->insert(symbol))
    {
      string err = "Multiple declaration of " + name + " in parameter";
      logError(ctx, err);
    }

    logRule(ctx, "parameter_list : parameter_list COMMA type_specifier ID");
    return types;
  }

  // whichever calls compound_statement must call enter scope and exit scope before and after.
  // it is not done inside compound_statement, since for functionDeclaration scope is entered at LPAREN before LCURL
  any visitCompoundStmtNonEmpty(CSubsetParser::CompoundStmtNonEmptyContext *ctx) override
  {
    visit(ctx->statements());
    logRule(ctx, "compound_statement : LCURL statements RCURL");
    return nullptr;
  }

  any visitCompoundStmtEmpty(CSubsetParser::CompoundStmtEmptyContext *ctx) override
  {
    logRule(ctx, "compound_statement : LCURL RCURL");
    return nullptr;
  }

  any visitVarDeclaration(CSubsetParser::VarDeclarationContext *ctx) override
  {
    visit(ctx->type_specifier());
    string type = ctx->type_specifier()->getText();
    vector<SymbolInfo *> symbols = any_cast<vector<SymbolInfo *>>(visit(ctx->declaration_list()));
    if (stringToType(type) == DataType::VOID)
    {
      logError(ctx, "Variable type cannot be void");
      // avoid subsequent errors
    }
    else
    {
      for (int i = 0; i < symbols.size(); i++)
      {
        SymbolInfo *symbolInfo = symbols[i];
        symbolInfo->getAuxInfo()->setDataType(type);
        if (!symbolTable->insert(symbolInfo))
        {
          string s = "Multiple declaration of " + symbolInfo->getName();
          logError(ctx, s);
        }
      }
    }
    logRule(ctx, "var_declaration : type_specifier declaration_list SEMICOLON");
    return nullptr;
  }

  any visitTypeSpecifierInt(CSubsetParser::TypeSpecifierIntContext *ctx) override
  {
    logRule(ctx, "type_specifier : INT");
    return DataType::INT;
  }

  any visitTypeSpecifierFloat(CSubsetParser::TypeSpecifierFloatContext *ctx) override
  {
    logRule(ctx, "type_specifier : FLOAT");
    return DataType::FLOAT;
  }

  any visitTypeSpecifierVoid(CSubsetParser::TypeSpecifierVoidContext *ctx) override
  {
    logRule(ctx, "type_specifier : VOID");
    return DataType::VOID;
  }

  any visitDeclarationListMultipleArr(CSubsetParser::DeclarationListMultipleArrContext *ctx) override
  {
    vector<SymbolInfo *> symbols = any_cast<vector<SymbolInfo *>>(visit(ctx->declaration_list()));
    string name = ctx->ID()->getText();
    int arraySize = stoi(ctx->CONST_INT()->getText());
    SymbolInfo *symbol = new SymbolInfo(name, "ID", arraySize);
    symbols.push_back(symbol);
    logRule(ctx, "declaration_list : declaration_list COMMA ID LTHIRD CONST_INT RTHIRD");
    return symbols;
  }

  any visitDeclarationListSingleArr(CSubsetParser::DeclarationListSingleArrContext *ctx) override
  {
    vector<SymbolInfo *> symbols;
    string name = ctx->ID()->getText();
    int arraySize = stoi(ctx->CONST_INT()->getText());
    SymbolInfo *symbol = new SymbolInfo(name, "ID", arraySize);
    symbols.push_back(symbol);
    logRule(ctx, "declaration_list : ID LTHIRD CONST_INT RTHIRD");
    return symbols;
  }

  any visitDeclarationListMultipleArrError(CSubsetParser::DeclarationListMultipleArrErrorContext *ctx) override
  {
    vector<SymbolInfo *> symbols = any_cast<vector<SymbolInfo *>>(visit(ctx->declaration_list()));
    // string name = ctx->ID()->getText();
    // names.push_back(name); //not inserting in symbol table
    logError(ctx, "Expression inside third brackets not an integer");
    // logRule(ctx, "declaration_list : declaration_list COMMA ID LTHIRD CONST_FLOAT RTHIRD");
    return symbols;
  }

  any visitDeclarationListSingleArrError(CSubsetParser::DeclarationListSingleArrErrorContext *ctx) override
  {
    vector<SymbolInfo *> symbols;
    // string name = ctx->ID()->getText();
    logError(ctx, "Expression inside third brackets not an integer");
    // logRule(ctx, "declaration_list: ID LTHIRD CONST_FLOAT RTHIRD");
    return symbols;
  }
  any visitStrayTokenDeclarationList(CSubsetParser::StrayTokenDeclarationListContext *ctx) override {
    vector<SymbolInfo *> symbols;
    SymbolInfo* symbol = new SymbolInfo(ctx->I1->getText(), "ID");
    symbols.push_back(symbol);
    string err = "syntax error, unexpected token(s) '" + ctx->children[1]->getText() + " " + ctx->I2->getText() + "' in declaration list"; //thanks to claude
    logRule(ctx, "declaration_list : ID", ctx->I1->getText());
    logError(ctx, err);
    // ID . ID
    return symbols;
  }

  any visitDeclarationListSingleId(CSubsetParser::DeclarationListSingleIdContext *ctx) override
  {
    vector<SymbolInfo *> symbols;
    string name = ctx->ID()->getText();
    SymbolInfo *symbol = new SymbolInfo(name, "ID");
    symbols.push_back(symbol);
    logRule(ctx, "declaration_list : ID");
    return symbols;
  }

  any visitDeclarationListMultipleVar(CSubsetParser::DeclarationListMultipleVarContext *ctx) override
  {
    vector<SymbolInfo *> symbols = any_cast<vector<SymbolInfo *>>(visit(ctx->declaration_list()));
    string name = ctx->ID()->getText();
    SymbolInfo *symbol = new SymbolInfo(name, "ID");
    symbols.push_back(symbol);
    logRule(ctx, "declaration_list : declaration_list COMMA ID");
    return symbols;
  }

  any visitMultipleStatements(CSubsetParser::MultipleStatementsContext *ctx) override
  {
    visit(ctx->statements());
    visit(ctx->statement());
    logRule(ctx, "statements : statements statement");
    return nullptr;
  }

  any visitSingleStatement(CSubsetParser::SingleStatementContext *ctx) override
  {
    visit(ctx->statement());
    logRule(ctx, "statements : statement");
    return nullptr;
  }

  any visitStatementVarDeclaration(CSubsetParser::StatementVarDeclarationContext *ctx) override
  {
    visit(ctx->var_declaration());
    logRule(ctx, "statement : var_declaration");
    return nullptr;
  }

  any visitStatementExpressionStmt(CSubsetParser::StatementExpressionStmtContext *ctx) override
  {
    visit(ctx->expression_statement());
    logRule(ctx, "statement : expression_statement");
    return nullptr;
  }

  any visitStatementCompoundStmt(CSubsetParser::StatementCompoundStmtContext *ctx) override
  {
    symbolTable->enterScope();
    visit(ctx->compound_statement());
    symbolTable->exitScope();
    logRule(ctx, "statement : compound_statement");
    return nullptr;
  }

  any visitStatementFor(CSubsetParser::StatementForContext *ctx) override
  {

    // symbolTable->enterScope(); // allowing (int i = 0; ) // current grammar does not support variable declaration here
    visit(ctx->e1);
    visit(ctx->e2);
    visit(ctx->expression());
    visit(ctx->statement());
    // symbolTable->exitScope();
    logRule(ctx, "statement : FOR LPAREN expression_statement expression_statement expression RPAREN statement");
    return nullptr;
  }

  any visitStatementIf(CSubsetParser::StatementIfContext *ctx) override
  {
    visit(ctx->expression());
    visit(ctx->statement());
    logRule(ctx, "statement : IF LPAREN expression RPAREN statement");
    return nullptr;
  }

  any visitStatementIfElse(CSubsetParser::StatementIfElseContext *ctx) override
  {
    visit(ctx->expression());
    visit(ctx->s1);
    visit(ctx->s2);
    logRule(ctx, "statement : IF LPAREN expression RPAREN statement ELSE statement");
    return nullptr;
  }

  any visitStatementWhile(CSubsetParser::StatementWhileContext *ctx) override
  {
    visit(ctx->expression());
    visit(ctx->statement());
    logRule(ctx, "statement : WHILE LPAREN expression RPAREN statement");
    return nullptr;
  }

  any visitStatementPrintln(CSubsetParser::StatementPrintlnContext *ctx) override
  {
    string name = ctx->ID()->getText();
    if (!symbolTable->lookUp(name))
    {
      logError(ctx, "Undeclared variable " + name);
    }
    logRule(ctx, "statement : PRINTLN LPAREN ID RPAREN SEMICOLON");
    return nullptr;
  }

  any visitStatementReturn(CSubsetParser::StatementReturnContext *ctx) override
  {
    visit(ctx->RETURN());
    visit(ctx->expression());
    logRule(ctx, "statement : RETURN expression SEMICOLON");
    return nullptr;
  }

  any visitExpressionStmtEmpty(CSubsetParser::ExpressionStmtEmptyContext *ctx) override
  {
    logRule(ctx, "expression_statement : SEMICOLON");
    return nullptr;
  }

  any visitExpressionStmtExpression(CSubsetParser::ExpressionStmtExpressionContext *ctx) override
  {
    visit(ctx->expression());
    logRule(ctx, "expression_statement : expression SEMICOLON");
    return nullptr;
  }

  any visitExpressionMissingSemicolon(CSubsetParser::ExpressionMissingSemicolonContext *ctx) override {
    visit(ctx->expression());
    string err = "syntax error, missing ';' after expression '"+ctx->expression()->getText() + "'";
    logError(ctx, err);
    logRule(ctx, "expression_statement : expression (missing SEMICOLON)");
    return nullptr;
  }

  any visitVariableId(CSubsetParser::VariableIdContext *ctx) override
  {
    string varName = ctx->ID()->getText();
    SymbolInfo *found = symbolTable->lookUp(varName);
    AuxInfo *r;
    if (found == NULL)
    {
      string err = "Undeclared variable " + varName;
      logError(ctx, err);
      r = new AuxInfo();
    }
    else
    {
      r = found->getAuxInfo();
    }
    logRule(ctx, "variable : ID");
    return r;
  }

  any visitVariableArr(CSubsetParser::VariableArrContext *ctx) override
  {
    string varName = ctx->ID()->getText();
    SymbolInfo *found = symbolTable->lookUp(varName);
    AuxInfo *r;
    if (found == NULL)
    {
      string err = "Undeclared variable " + varName;
      logError(ctx, err);
      r = new AuxInfo();
    }
    else
    {
      AuxInfo *auxInfo = found->getAuxInfo();
      r = new AuxInfo(auxInfo->getDataType());
      if (!auxInfo->getIsArray())
      {
        string err = varName + " not an array";
        logError(ctx, err);
        // return auxInfo;
      }
      else
      {
        AuxInfo *auxInfo2 = any_cast<AuxInfo *>(visit(ctx->expression()));
        if (auxInfo2->getDataType() != DataType::INT)
        {
          logError(ctx, "Expression inside third brackets not an integer");
          // return auxInfo;
        }
      }
    }
    logRule(ctx, "variable : ID LTHIRD expression RTHIRD");

    return r;
  }

  any visitExpressionLogicExpression(CSubsetParser::ExpressionLogicExpressionContext *ctx) override
  {
    AuxInfo *auxInfo = any_cast<AuxInfo *>(visit(ctx->logic_expression()));
    logRule(ctx, "expression : logic expression");
    return auxInfo;
  }

  any visitExpressionVarAssignLogic(CSubsetParser::ExpressionVarAssignLogicContext *ctx) override
  {
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->variable()));
    AuxInfo *a2 = any_cast<AuxInfo *>(visit(ctx->logic_expression()));
    // string name = ctx->variable()->getText();
    // string type = symbolTable->getDataType(name);

    // to avoid further checking
    if(a2->getDataType() == DataType::VOID){
      logError(ctx,"Void function used in expression");
    }
    else if (a1->getDataType() == DataType::ERROR || a2->getDataType() == DataType::ERROR)
    {
      a1 = new AuxInfo(DataType::ERROR);
    }
    else
    {

      if (a1->getIsArray())
      {
        string err = "Type mismatch, " + ctx->variable()->getText() + " is an array";
        logError(ctx, err);
        // return a1;
      }
      else
      {
        DataType r = intFloatAssignCheck(a1->getDataType(), a2->getDataType());
        if (r == DataType::ERROR)
        { //?
          string err = "Type Mismatch";
          logError(ctx, err);
          // return a1;
        }
      }
    }
    logRule(ctx, "expression : variable ASSIGNOP logic_expression");
    return a1;
  }

  any visitLogicExprRelExpr(CSubsetParser::LogicExprRelExprContext *ctx) override
  {
    AuxInfo *auxInfo = any_cast<AuxInfo *>(visit(ctx->rel_expression()));
    logRule(ctx, "logic_expression : rel_expression");
    return auxInfo;
  }

  any visitLogicExprWLogicOp(CSubsetParser::LogicExprWLogicOpContext *ctx) override
  {
    AuxInfo *t1 = any_cast<AuxInfo *>(visit(ctx->r1));
    AuxInfo *t2 = any_cast<AuxInfo *>(visit(ctx->r2));
    AuxInfo *r = new AuxInfo(DataType::INT);
    if (t1->getDataType() != DataType::INT || t2->getDataType() != DataType::INT)
    {
      string err = ctx->LOGICOP()->getText() + " is not defined for these operands ";
      logError(ctx, err);
    }
    logRule(ctx, "logic_expression : rel_expression LOGICOP rel_expression");

    return r; // logicop always int
  }

  any visitRelExprSimpleExpr(CSubsetParser::RelExprSimpleExprContext *ctx) override
  {
    AuxInfo *auxInfo = any_cast<AuxInfo *>(visit(ctx->simple_expression()));
    logRule(ctx, "rel_expression : simple_expression");
    return auxInfo;
  }

  any visitRelExprWRelOp(CSubsetParser::RelExprWRelOpContext *ctx) override
  {
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->s1));
    AuxInfo *a2 = any_cast<AuxInfo *>(visit(ctx->s2));
    AuxInfo *r = new AuxInfo(DataType::INT);
    // to avoid further checking
    if (a1->getDataType() == DataType::ERROR || a2->getDataType() == DataType::ERROR)
    {
      r = new AuxInfo(DataType::ERROR);
    }
    else
    {
      DataType t = intFloatCheck(a1->getDataType(), a2->getDataType());
      if (t == DataType::ERROR)
      {
        logError(ctx, "type mismatch");
        // r = new AuxInfo(DataType::ERROR);
      }
    }
    logRule(ctx, "rel_expression : simple_expression RELOP simple_expression");
    return r; // result always int ?? if mismatch?
  }

  any visitStraySimpleExpr(CSubsetParser::StraySimpleExprContext *ctx) override {
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->term()));
    logRule(ctx, "simple_expression : term"); //term ADDOP stray=(ASSIGNOP|RELOP|MULOP|LOGICOP) #straySimpleExpr
    string err = "syntax error, invalid operand '"+ctx->stray->getText()+"' after '+'";
    logError(ctx->term(), err);
    return a1;
  }
  any visitSimpleExprTerm(CSubsetParser::SimpleExprTermContext *ctx) override
  {
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->term()));
    logRule(ctx, "simple_expression : term");
    return a1;
  }

  any visitSimpleExprAdd(CSubsetParser::SimpleExprAddContext *ctx) override
  {
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->simple_expression()));
    AuxInfo *a2 = any_cast<AuxInfo *>(visit(ctx->term()));
    AuxInfo *r;

    if (a1->getDataType() == DataType::ERROR || a2->getDataType() == DataType::ERROR)
    {
      r = new AuxInfo(DataType::ERROR);
    }
    else
    {
      DataType t = intFloatCheck(a1->getDataType(), a2->getDataType());
      r = new AuxInfo(t);
      if (t == DataType::ERROR)
      {
        logError(ctx, "type mismatch");
      }
    }
    logRule(ctx, "simple_expression : simple_expression ADDOP term");
    return r;
  }

  any visitTermUnaryExpr(CSubsetParser::TermUnaryExprContext *ctx) override
  {
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->unary_expression()));
    logRule(ctx, "term : unary_expression");
    return a1;
  }

  any visitTermMul(CSubsetParser::TermMulContext *ctx) override
  {
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->term()));
    AuxInfo *a2 = any_cast<AuxInfo *>(visit(ctx->unary_expression()));
    AuxInfo *r = new AuxInfo(DataType::ERROR);
    if ((a1->getDataType() == DataType::VOID) || (a2->getDataType() == DataType::VOID))
    {
      logError(ctx, "Void function used in expression");
    }
    else if (ctx->MULOP()->getText() == "%" && (a1->getDataType() != DataType::INT || a2->getDataType() != DataType::INT))
    {
      logError(ctx, "Non-Integer operand on modulus operator");
    }
    else if (ctx->MULOP()->getText() == "%" && (ctx->unary_expression()->getText() == "0"))
    {
      logError(ctx, "Modulus by Zero");
    }
    else if (a1->getDataType() == DataType::ERROR || a2->getDataType() == DataType::ERROR)
    {
      r = new AuxInfo(DataType::ERROR);
    }
    else
    {
      DataType t = intFloatCheck(a1->getDataType(), a2->getDataType());
      r = new AuxInfo(t);
      if (t == DataType::ERROR)
      {
        logError(ctx, "type mismatch");
      }
    }
    logRule(ctx, "term : term MULOP unary_expression");
    return r;
  }

  any visitUnaryExprAdd(CSubsetParser::UnaryExprAddContext *ctx) override
  {
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->unary_expression()));
    if(a1->getDataType() == DataType::VOID){
      logError(ctx, "Void function used in expression");
      a1 = new AuxInfo(DataType::ERROR);
    }
    else if (a1->getDataType() != DataType::INT && a1->getDataType() != DataType::FLOAT)
    {
      logError(ctx, "invalid operand for unary operation");
    }
    logRule(ctx, "unary_expression : ADDOP unary_expression");
    return a1;
  }

  any visitUnaryExprNot(CSubsetParser::UnaryExprNotContext *ctx) override
  {
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->unary_expression()));
    AuxInfo *r;
    if(a1->getDataType() == DataType::VOID){
      logError(ctx, "Void function used in expression");
      r = new AuxInfo(DataType::ERROR);
    }
    else if (a1->getDataType() != DataType::INT && a1->getDataType() != DataType::FLOAT)
    {
      logError(ctx, "invalid operand for unary operation");
      // r = a1; ??
    }
    logRule(ctx, "unary_expression : NOT unary expression");
    r = new AuxInfo(DataType::INT);
    return r; // boolean like always int
  }

  any visitUnaryExprFactor(CSubsetParser::UnaryExprFactorContext *ctx) override
  {
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->factor()));
    logRule(ctx, "unary_expression : factor");
    return a1;
  }

  any visitFactorVar(CSubsetParser::FactorVarContext *ctx) override
  {
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->variable()));
    logRule(ctx, "factor : variable");
    return a1;
  }

  any visitFactorArgList(CSubsetParser::FactorArgListContext *ctx) override
  {
    string funcName = ctx->ID()->getText();
    SymbolInfo *found = symbolTable->lookUp(funcName);
    if (found == NULL)
    {
      string err = "Undeclared function " + funcName;
      logError(ctx, err);
      AuxInfo *r = new AuxInfo();
      return r;
    }
    AuxInfo *a1 = found->getAuxInfo();
    // if (a1->getDataType() == DataType::VOID)
    // {
    //   logError(ctx, "Void function used in expression");
    //   return new AuxInfo();
    // }
    // vector<AuxInfo*> args = any_cast<vector<AuxInfo*>>(visit(ctx->argument_list()));
    vector<AuxInfo *> args = any_cast<vector<AuxInfo *>>(visit(ctx->argument_list()));
    vector<DataType> original = a1->getArgTypes();

    if (args.size() != original.size())
    {
      string err = "Total number of arguments mismatch in function " + funcName;
      logError(ctx, err);
    }
    else{
      string err = string("");
      for (int i = 0; i < original.size(); i++)
      {
        // if (args[i]->getIsArray() == true)
        // {
        //   string err = "Type mismatch is an array";
        //   logError(ctx, err);
        // }
        // else
        // {
          if (args[i]->getDataType() != DataType::ERROR && original[i] != args[i]->getDataType())
          {
            err += to_string(i + 1);
            err += "th argument mismatch in function ";
            err += funcName;
            logError(ctx, err);
            break;
          }
        //}
      }
    }
    logRule(ctx, "factor : ID LPAREN argument_list RPAREN");
    return a1;
  }

  any visitFactorExpr(CSubsetParser::FactorExprContext *ctx) override
  {
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->expression()));
    logRule(ctx, "factor : LPAREN expression RPAREN");
    return a1;
  }

  any visitFactorConstInt(CSubsetParser::FactorConstIntContext *ctx) override
  {
    logRule(ctx, "factor : CONST_INT");
    AuxInfo *r = new AuxInfo(DataType::INT);
    return r;
  }

  any visitFactorConstFloat(CSubsetParser::FactorConstFloatContext *ctx) override
  {
    logRule(ctx, "factor : CONST_FLOAT");
    AuxInfo *r = new AuxInfo(DataType::FLOAT);
    return r;
  }

  any visitFactorIncOp(CSubsetParser::FactorIncOpContext *ctx) override
  {
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->variable()));
    if (a1->getDataType() != DataType::INT && a1->getDataType() != DataType::FLOAT)
    {
      logError(ctx, "invalid arg to incop");
      return a1;
    }
    logRule(ctx, "factor : variable INCOP");
    return a1;
  }

  any visitFactorDecOp(CSubsetParser::FactorDecOpContext *ctx) override
  {
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->variable()));
    if (a1->getDataType() != DataType::INT && a1->getDataType() != DataType::FLOAT)
    {
      logError(ctx, "invalid arg to decop");
      return a1;
    }
    logRule(ctx, "factor : variable DECOP");
    return a1;
  }

  any visitArgumentListMultipleArgs(CSubsetParser::ArgumentListMultipleArgsContext *ctx) override
  {
    vector<AuxInfo *> types = any_cast<vector<AuxInfo *>>(visit(ctx->arguments()));
    logRule(ctx, "argument_list : arguments");
    return types;
  }

  any visitArgumentListNoArgs(CSubsetParser::ArgumentListNoArgsContext *ctx) override
  {
    vector<AuxInfo *> types;
    logRule(ctx, "argument_list : ");
    return types;
  }

  any visitArgumentsLogicExpr(CSubsetParser::ArgumentsLogicExprContext *ctx) override
  {
    vector<AuxInfo *> args;
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->logic_expression()));
    
    if (a1->getIsArray() == true)
    {
      string err = "Type mismatch, " + ctx->logic_expression()->getText() + " is an array";
      a1 = new AuxInfo(DataType::ERROR);
      logError(ctx, err);
    }
    args.push_back(a1);
    logRule(ctx, "arguments : logic_expression");
    return args;
  }

  any visitArgumentsCommaLogicExpr(CSubsetParser::ArgumentsCommaLogicExprContext *ctx) override
  {
    vector<AuxInfo *> args = any_cast<vector<AuxInfo *>>(visit(ctx->arguments()));
    AuxInfo *a1 = any_cast<AuxInfo *>(visit(ctx->logic_expression()));
    if (a1->getIsArray() == true)
    {
      string err = "Type mismatch, " + ctx->logic_expression()->getText() + " is an array";
      a1 = new AuxInfo(DataType::ERROR);
      logError(ctx, err);
    }
    args.push_back(a1);
    logRule(ctx, "arguments : arguments COMMA logic_expression");
    return args;
  }
};